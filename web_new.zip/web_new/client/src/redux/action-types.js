export const SET_HEAD_TITLE = 'set_head_title';
export const RECEIVE_USER = 'receive_user';
export const SHOW_ERROR_MSG = 'show_error_msg';
export const RESET_USER = 'reset_user';