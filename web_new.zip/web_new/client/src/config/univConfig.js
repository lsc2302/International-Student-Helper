export const univConfig=['Peking University','Tsinghua University','FuDan University',
    'Zhejiang University','Renmin University','ShanghaiJiaoTong University'];